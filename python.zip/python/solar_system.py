import vpython
from vpython import vector, mag, norm, color, rate, textures

vpython.canvas(title='My Solar System')

# Gravitatieconstante (SI)
G = 6.674e-11


# =====================================================================
# Inlezen en gebruiken van het gegevensbestand
# =====================================================================
# Het bestand 'planeten.txt' bevat de gegevens van de zon, de planeten
# en de manen. Vaststellingen (zie uitleg):
#   - de eerste 3 lijnen hebben we niet nodig -> skip_header (hier: [3:])
#   - de zon heeft 4 gegevens, de planeten 6 en de manen 7.
#     We zorgen dat we voor elk hemellichaam 6 parameters bekomen:
#       * zon  : OrbitRad en OrbitVel bestaan niet -> we vullen 0 in
#       * maan : bevat het overbodige woord "moon" -> dit laten we weg
#   - de gegevens zijn gescheiden door een komma; strip() haalt \n en
#     overbodige spaties weg, split(',') splitst de gegevens op.
# De parameters worden naar het juiste type omgezet (float / str), want
# alle ingelezen gegevens zijn aanvankelijk strings.

class Hemellichamen:
    # Eenvoudige cache zodat het bestand niet duizenden keren opnieuw moet
    # worden ingelezen tijdens de while-lus (gedrag blijft identiek).
    _cache = {}

    def __init__(self, Name, BodyRad, OrbitRad, Mass, OrbitVel, Color):
        self.Name = Name
        self.BodyRad = BodyRad
        self.OrbitRad = OrbitRad
        self.Mass = Mass
        self.OrbitVel = OrbitVel
        self.Color = Color

    @staticmethod
    def planets_from_file(filename):
        if filename in Hemellichamen._cache:
            return Hemellichamen._cache[filename]

        bodies = []
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()[3:]          # eerste 3 lijnen overslaan

        for line in lines:
            line = line.strip()
            if not line:
                continue

            parts = [p.strip() for p in line.split(',')]
            # het woord "moon" bij de manen is overbodig -> weglaten
            parts = [p for p in parts if p.lower() != 'moon']

            if len(parts) == 4:
                # zon: Name, BodyRad, Mass, Color (OrbitRad en OrbitVel = 0)
                name, body_rad, mass, kleur = parts
                orbit_rad = 0
                orbit_vel = 0
            else:
                # planeet / maan: Name, BodyRad, OrbitRad, Mass, OrbitVel, Color
                name, body_rad, orbit_rad, mass, orbit_vel, kleur = parts

            bodies.append(Hemellichamen(
                name,
                float(body_rad),
                float(orbit_rad),
                float(mass),
                float(orbit_vel),
                kleur,
            ))

        Hemellichamen._cache[filename] = bodies
        return bodies


# =====================================================================
# Hulpfuncties (fysica)
# =====================================================================

def calc_gravitational_acceleration(m, r):
    # Aantrekkingskracht tussen twee lichamen:
    #   g = - G * (M_zon * M_planeet) * r_hat / |r|^2
    # norm(r) geeft de eenheidsvector van r, mag(r) de lengte van r.
    return -G * m * norm(r) / mag(r) ** 2


def inc_momentum(p, g, dt):
    # p_t = p_(t-1) + g * dt
    return vector(p) + vector(g) * dt


def inc_position(r, p, m, dt):
    # r_t = r_(t-1) + (p_t / m) * dt
    return vector(r) + (vector(p) * dt) / m


# =====================================================================
# Eigen uitbreiding: textuur in plaats van een vlakke kleur
# =====================================================================

def color_naar_texture(k):
    if Hemellichamen.planets_from_file('planeten.txt')[k].Color == "orange":
        return textures.wood
    elif Hemellichamen.planets_from_file('planeten.txt')[k].Color == "white":
        return textures.rock
    elif Hemellichamen.planets_from_file('planeten.txt')[k].Color == "red":
        return textures.wood_old
    elif Hemellichamen.planets_from_file('planeten.txt')[k].Color == "blue":
        return textures.earth


# =====================================================================
# simulate_earth: zon + aarde (+ maan als uitbreiding)
# =====================================================================

def simulate_earth(n, dt):
    Sun = vpython.sphere(pos=vector(0, 0, 0),
                         radius=70 * Hemellichamen.planets_from_file('planeten.txt')[0].BodyRad,
                         color=color.yellow)

    Earth = vpython.sphere(pos=vector(Hemellichamen.planets_from_file('planeten.txt')[3].OrbitRad, 0, 0),
                           radius=2800 * Hemellichamen.planets_from_file('planeten.txt')[3].BodyRad,
                           texture=textures.earth, make_trail=True)
    # afstand bepaald tussen het middelpunt van de zon en het middelpunt van de aarde

    t = 0

    Earth.momentum = Hemellichamen.planets_from_file('planeten.txt')[3].Mass * vector(0, Hemellichamen.planets_from_file('planeten.txt')[3].OrbitVel, 0)
    Sun.momentum = - Earth.momentum
    # Hiermee worden de beginmomenta van de zon en de aarde bepaald

    Moon = vpython.sphere(pos=vector(Hemellichamen.planets_from_file('planeten.txt')[3].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[3].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[4].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[4].BodyRad, 0, 0),
                          radius=2800 * Hemellichamen.planets_from_file('planeten.txt')[4].BodyRad,
                          texture=textures.stucco)
    # Uitbreiding -> handig voor simulate_solar_system
    # afstand zon-maan = afstand zon-aarde (m) + straal aarde (m) + afstand aarde-maan (km -> *1000) + straal maan (m)
    # we tellen de stralen op (en vergroten ze) zodat de maan niet in de aarde zit

    while t < n:
        rate(1000)

        g = calc_gravitational_acceleration(Hemellichamen.planets_from_file('planeten.txt')[3].Mass * Hemellichamen.planets_from_file('planeten.txt')[0].Mass, Earth.pos - Sun.pos)
        Earth.momentum = inc_momentum(Earth.momentum, g, dt)
        Sun.momentum = inc_momentum(Sun.momentum, -g, dt)
        # Update momentum van de zon en aarde

        Earth.pos = inc_position(Earth.pos, Earth.momentum, Hemellichamen.planets_from_file('planeten.txt')[3].Mass, dt)
        Sun.pos = inc_position(Sun.pos, Sun.momentum, Hemellichamen.planets_from_file('planeten.txt')[0].Mass, dt)
        Moon.pos = Earth.pos + (2800 * Hemellichamen.planets_from_file('planeten.txt')[3].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[4].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[4].BodyRad) * norm(Earth.pos)
        # Update positie van de aarde, de zon en de maan
        # De maan volgt de beweging van de aarde via de eenheidsvector norm(Earth.pos)

        t += dt


# =====================================================================
# simulate_planets: zon + 5 planeten
# =====================================================================

def simulate_planets(n, dt):
    Sun = vpython.sphere(pos=vector(0, 0, 0),
                         radius=50 * Hemellichamen.planets_from_file('planeten.txt')[0].BodyRad,
                         color=color.yellow)

    planet_lines = [1, 2, 3, 5, 8]
    # Een lijst met de indexen van de lijnen van de planeten in het gegevensbestand

    planet_list = []
    momentum_list = []
    # Aanmaken 2 blanco lijsten

    for i in planet_lines:
        C = color_naar_texture(i)
        Name_planet = Hemellichamen.planets_from_file('planeten.txt')[i].Name
        Name_planet = vpython.sphere(pos=vector(Hemellichamen.planets_from_file('planeten.txt')[i].OrbitRad, 0, 0),
                                     radius=2800 * Hemellichamen.planets_from_file('planeten.txt')[i].BodyRad,
                                     texture=C, make_trail=True)
        planet_list += [Name_planet]
        # De 5 planeten (met hun positie, radius, texture, ...) worden in lijst "planet_list" gestoken

        momentum_p = Hemellichamen.planets_from_file('planeten.txt')[i].Mass * vector(0, Hemellichamen.planets_from_file('planeten.txt')[i].OrbitVel, 0)
        Sun.momentum = - momentum_p
        momentum_list += [momentum_p]
        # Beginmomenta van de zon en van elke planeet worden berekend
        # De beginmomenta van de 5 planeten worden in de lijst "momentum_list" gestoken

    t = 0

    while t < n:
        rate(1000)
        t += dt

        for index, planet in enumerate(planet_list):
            g = calc_gravitational_acceleration(Hemellichamen.planets_from_file('planeten.txt')[planet_lines[index]].Mass * Hemellichamen.planets_from_file('planeten.txt')[0].Mass, planet.pos - Sun.pos)
            momentum_list[index] = inc_momentum(momentum_list[index], g, dt)
            Sun.momentum = inc_momentum(Sun.momentum, -g, dt)
            # Update momentum van de zon en van elke planeet
            # De 5 momenta in "momentum_list" worden overschreven met de nieuw berekende momenta

            planet.pos = inc_position(planet.pos, momentum_list[index], Hemellichamen.planets_from_file('planeten.txt')[planet_lines[index]].Mass, dt)
            Sun.pos = inc_position(Sun.pos, Sun.momentum, Hemellichamen.planets_from_file('planeten.txt')[0].Mass, dt)
            # Update positie van de zon en van elke planeet, rekening houdend met de nieuwe momenta


# =====================================================================
# simulate_solar_system: zon + 5 planeten + 7 manen
# =====================================================================

def simulate_solar_system(n, dt):
    Sun = vpython.sphere(pos=vector(0, 0, 0),
                         radius=20 * Hemellichamen.planets_from_file('planeten.txt')[0].BodyRad,
                         color=color.yellow)

    planet_lines = [1, 2, 3, 5, 8]
    # Een lijst met de indexen van de lijnen van de planeten in het gegevensbestand

    moon_lines = [4, 6, 7, 9, 10, 11, 12]
    # Een lijst met de indexen van de lijnen van de manen in het gegevensbestand

    van_planeten = [3, 5, 5, 8, 8, 8, 8]
    # De lijst met de indexen van de bij de maan horende planeet

    planet_list = []
    moon_list = []
    momentum_list = []
    position_planet = []
    # Aanmaken 4 blanco lijsten

    for i in planet_lines:
        C = color_naar_texture(i)
        Name_planet = Hemellichamen.planets_from_file('planeten.txt')[i].Name
        Name_planet = vpython.sphere(pos=vector(Hemellichamen.planets_from_file('planeten.txt')[i].OrbitRad, 0, 0),
                                     radius=2800 * Hemellichamen.planets_from_file('planeten.txt')[i].BodyRad,
                                     texture=C, make_trail=True)
        planet_list += [Name_planet]
        # De 5 planeten (met hun positie, radius, texture, ...) worden in lijst "planet_list" gestoken

        position_planet += [Name_planet.pos]
        # De beginposities van de 5 planeten worden in de lijst "position_planet" gestoken

        momentum_p = Hemellichamen.planets_from_file('planeten.txt')[i].Mass * vector(0, Hemellichamen.planets_from_file('planeten.txt')[i].OrbitVel, 0)
        Sun.momentum = - momentum_p
        momentum_list += [momentum_p]
        # De beginmomenta van de 5 planeten en de zon worden berekend
        # De beginmomenta van de 5 planeten worden in de lijst "momentum_list" gestoken

    for j, m in enumerate(moon_lines):
        Name_moon = Hemellichamen.planets_from_file('planeten.txt')[m].Name
        # BodyRad van de maan van de aarde staat in meter, die van de andere manen in km
        # -> onderscheid maken: maan van de aarde (al in m) vs. andere manen (km -> *1000)
        # OrbitRad van alle manen staat in km -> *1000 (zelfde eenheid als planeten)
        # Om de manen zichtbaar te maken vermenigvuldigen we de radius met een factor.
        # De manen van Mars zijn veel kleiner dan die van Aarde/Jupiter -> aparte factor.
        # Om de manen niet op elkaar te laten vallen: positievector afhankelijk van de
        # index van de maan (j * 20000000000).

        if j == 0:
            # maan van de aarde (BodyRad in meter)
            Name_moon = vpython.sphere(pos=vector(j * 20000000000 + Hemellichamen.planets_from_file('planeten.txt')[van_planeten[j]].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[van_planeten[j]].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[m].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[j]].BodyRad, 0, 0),
                                       radius=2800 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[j]].BodyRad,
                                       texture=textures.stucco)
        elif j < 3:
            # manen van Mars (BodyRad in km -> *1000, en extra grote factor want klein)
            Name_moon = vpython.sphere(pos=vector(j * 20000000000 + Hemellichamen.planets_from_file('planeten.txt')[van_planeten[j]].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[van_planeten[j]].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[m].OrbitRad + 360000 * 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[j]].BodyRad, 0, 0),
                                       radius=360000 * 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[j]].BodyRad,
                                       texture=textures.stucco)
        else:
            # manen van Jupiter (BodyRad in km -> *1000)
            Name_moon = vpython.sphere(pos=vector(j * 20000000000 + Hemellichamen.planets_from_file('planeten.txt')[van_planeten[j]].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[van_planeten[j]].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[m].OrbitRad + 2800 * 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[j]].BodyRad, 0, 0),
                                       radius=2800 * 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[j]].BodyRad,
                                       texture=textures.stucco)

        moon_list += [Name_moon]
        # De 7 manen (met hun positie, radius, texture, ...) worden in de lijst "moon_list" gestoken

    t = 0

    while t < n:
        rate(10000)
        t += dt

        for index, planet in enumerate(planet_list):
            g = calc_gravitational_acceleration(Hemellichamen.planets_from_file('planeten.txt')[planet_lines[index]].Mass * Hemellichamen.planets_from_file('planeten.txt')[0].Mass, planet.pos - Sun.pos)
            momentum_list[index] = inc_momentum(momentum_list[index], g, dt)
            Sun.momentum = inc_momentum(Sun.momentum, -g, dt)
            # Update momentum van de zon en van elke planeet
            # De 5 momenta in "momentum_list" worden overschreven met de nieuw berekende momenta

            planet.pos = inc_position(planet.pos, momentum_list[index], Hemellichamen.planets_from_file('planeten.txt')[planet_lines[index]].Mass, dt)
            position_planet[index] = planet.pos
            Sun.pos = inc_position(Sun.pos, Sun.momentum, Hemellichamen.planets_from_file('planeten.txt')[0].Mass, dt)
            # Update positie van de zon en van elke planeet
            # De 5 posities in "position_planet" worden overschreven met de nieuw berekende posities

        for z, moon in enumerate(moon_list):
            if z == 0:
                moon.pos = position_planet[planet_lines.index(van_planeten[z])] + (z * 20000000000 + 2800 * Hemellichamen.planets_from_file('planeten.txt')[van_planeten[z]].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[z]].OrbitRad + 2800 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[z]].BodyRad) * norm(position_planet[planet_lines.index(van_planeten[z])])
            elif z < 3:
                moon.pos = position_planet[planet_lines.index(van_planeten[z])] + (z * 20000000000 + 2800 * Hemellichamen.planets_from_file('planeten.txt')[van_planeten[z]].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[z]].OrbitRad + 360000 * 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[z]].BodyRad) * norm(position_planet[planet_lines.index(van_planeten[z])])
            else:
                moon.pos = position_planet[planet_lines.index(van_planeten[z])] + (z * 20000000000 + 2800 * Hemellichamen.planets_from_file('planeten.txt')[van_planeten[z]].BodyRad + 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[z]].OrbitRad + 2800 * 1000 * Hemellichamen.planets_from_file('planeten.txt')[moon_lines[z]].BodyRad) * norm(position_planet[planet_lines.index(van_planeten[z])])
            # Update positie van de 7 manen
            # index*afstand (20000000000) zorgt dat manen niet samenvallen
            # norm(...) zorgt dat de manen de beweging van de bijhorende planeet volgen


# =====================================================================
# Aanroepen van de simulatie
# =====================================================================
# n (aarde)   = 1 jaar  in seconden  = 60 * 60 * 24 * 366
# n (jupiter) = 12 jaar in seconden  = 60 * 60 * 24 * 366 * 12  (grootste baan)
# dt = 3600 seconden (1 uur)

# simulate_earth((60 * 60 * 24 * 366), 3600)
# simulate_planets((60 * 60 * 24 * 366 * 12), 3600)
simulate_solar_system((60 * 60 * 24 * 366 * 12), 3600)
